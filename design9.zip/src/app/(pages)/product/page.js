import Product from '@/app/_component/Product'
import React from 'react'

export default function page() {
  return (
    <>
    <Product/>
    </>
  )
}
